let uktanah = 20.5*30
let harga = 1500000

let total = (uktanah*harga);
let ppn = ((15/100)*total);
let totalppn = (total+ppn);
console.log("Harga tanah " + uktanah + " meter persegi = Rp. " + total)
console.log("Harga tanah + PPN = Rp. "+totalppn);

